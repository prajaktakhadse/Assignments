package com.masai.project.Model;

public enum LoginStatus {
	
	LOGGED_IN, LOGGED_OUT

}
