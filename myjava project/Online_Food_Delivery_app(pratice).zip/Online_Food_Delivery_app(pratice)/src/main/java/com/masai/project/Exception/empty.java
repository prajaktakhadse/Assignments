package com.masai.project.Exception;

public class empty {

}
