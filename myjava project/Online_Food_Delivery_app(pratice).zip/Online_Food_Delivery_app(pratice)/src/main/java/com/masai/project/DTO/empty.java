package com.masai.project.DTO;

public class empty {

}
