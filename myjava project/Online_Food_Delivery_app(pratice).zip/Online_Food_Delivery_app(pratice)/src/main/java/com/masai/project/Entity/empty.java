package com.masai.project.Entity;

public class empty {

}
