package com.masai.project.Model;

public class empty {

}
