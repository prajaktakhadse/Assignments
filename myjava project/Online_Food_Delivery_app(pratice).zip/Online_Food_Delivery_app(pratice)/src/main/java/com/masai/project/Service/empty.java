package com.masai.project.Service;

public class empty {

}
