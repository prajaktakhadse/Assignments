package com.masai.project.Exception;

public class GlobalExceptionHandler {

}
